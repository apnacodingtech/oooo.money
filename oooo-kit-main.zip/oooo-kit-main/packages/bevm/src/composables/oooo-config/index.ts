import { OConfigContext } from './context'

export const OConfigProvider = OConfigContext.Provider

export { useOConfig } from './context'
