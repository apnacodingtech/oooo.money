# @oooo-kit/bevm

## 0.2.1

### Patch Changes

- 8097fab: fix wallet address empty cause component crash error

## 0.2.0

### Minor Changes

- 2ae8f09: add showMessageAlert option and onSuccess/onFailed callback

## 0.1.2

### Patch Changes

- e247302: fix typo

## 0.1.1

### Patch Changes

- e474131: fix antd style conflict error

## 0.1.0

### Minor Changes

- ab194e6: Publish 1.0.0 version
