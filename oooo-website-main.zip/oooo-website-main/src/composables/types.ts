export interface ExampleType {
  KEY: string
}
