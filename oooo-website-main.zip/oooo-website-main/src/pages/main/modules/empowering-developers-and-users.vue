<script setup lang="ts">

</script>

<template>
  <div class="mt-[90px] md:mt-[180px]">
    <h3 class="text-[28px] md:text-[48px] font-[500] text-center leading-[1]">
      EMPOWERING DEVELOPERS AND USERS
    </h3>
    <div class="mt-[30px] md:mt-[60px] flex flex-col xl:flex-row items-center gap-[30px] md:gap-[60px]">
      <div class="w-full">
        <p class="text-[20px] md:text-[32px] text-[#bce4cd]">
          HIGH INTEROPERABILITY
        </p>
        <p class="mt-[20px] text-[14px] text-[#848484]">
          oooo DELIVERS HIGH INTEROPERABILITY BY SEAMLESSLY CONNECTING DIVERSE BLOCKCHAIN ECOSYSTEMS AND CENTRALIZED FINANCIAL SYSTEMS, ENABLING FLUID COMMUNICATION AND INTERACTION ACROSS MULTIPLE NETWORKS.
          <br><br>
          THIS ADVANCED LEVEL OF INTEROPERABILITY UNLOCKS SIGNIFICANT LIQUIDITY WITHIN BOTH BLOCKCHAINS AND CENTRALIZED FINANCIAL INSTITUTIONS, ENSURING THAT ASSETS, DATA, AND TRANSACTIONS MOVE FREELY AND SECURELY BETWEEN CHAINS.
          <br><br>
          BY ELIMINATING SILOS AND ENHANCING THE EFFICIENCY OF DAPPS, oooo’S INTEROPERABILITY FRAMEWORK EMPOWERS DEVELOPERS AND USERS TO ACCESS AND LEVERAGE A VAST, INTERCONNECTED NETWORK WITH EASE, WHETHER IT'S BRIDGING ASSETS, INTEGRATING FINANCIAL SERVICES, OR SUPPORTING COMPLEX MULTI-CHAIN OPERATIONS.
        </p>
      </div>
      <div class="w-full aspect-[2/1]">
        <img
          class="w-full h-full"
          src="@/assets/images/high-interoperability.png"
        >
      </div>
    </div>
    <div class="mt-[30px] md:mt-[60px] flex flex-col-reverse xl:flex-row items-center gap-[30px] md:gap-[60px]">
      <div class="w-full aspect-[2/1]">
        <img
          class="w-full h-full"
          src="@/assets/images/all-in-one.png"
        >
      </div>
      <div class="w-full">
        <p class="text-[20px] md:text-[32px] text-[#bce4cd]">
          ALL-IN-ONE EXCHANGE
        </p>
        <p class="mt-[20px] text-[14px] text-[#848484]">
          oooo’S ALL-IN-ONE EXCHANGE OFFERS A UNIFIED INTERFACE THAT SEAMLESSLY COMBINES ON-CHAIN AND OFF-CHAIN PLATFORMS, BRINGING TOGETHER ALL ESSENTIAL FUNCTIONALITIES UNDER ONE ROOF. BY INTEGRATING LIQUIDITY SOURCES AND VARIOUS FEATURES LIKE BRIDGING, SWAPPING, AND PAYMENTS INTO A SINGLE, COHESIVE PLATFORM, oooo SIMPLIFIES THE USER AND DEVELOPER EXPERIENCE.
          <br><br>
          THIS UNIFIED APPROACH ELIMINATES THE NEED FOR MULTIPLE TOOLS AND PLATFORMS, ENABLING MORE CONVENIENT AND EFFICIENT ASSET MANAGEMENT, AND FOSTERING A SMOOTHER, MORE STREAMLINED INTERACTION.
        </p>
      </div>
    </div>
    <div class="mt-[30px] md:mt-[60px]">
      <p class="md:text-[32px] text-[#bce4cd]">
        ASSET ABSTRACTION
      </p>
      <div class="mt-[30px] md:mt-[20px] flex flex-col md:flex-row gap-[21px] md:gap-[60px] text-[14px] text-[#848484]">
        <p class="w-full">
          oooo ENVISIONS A FUTURE WHERE ASSET ABSTRACTION REDEFINES ASSET MANAGEMENT BY MAKING IT INTENT-CENTRIC, EFFICIENT, AND FREE OF COMPLEXITY FOR BOTH USERS AND DEVELOPERS.
          <br><br>
          BY ABSTRACTING ASSETS ACROSS VARIOUS BLOCKCHAINS AND FINANCIAL SYSTEMS, oooo AIMS TO ENABLE SEAMLESS ASSET MOVEMENT BETWEEN NETWORKS, ENHANCING LIQUIDITY AND LOWERING BARRIERS FOR NEW USERS.
        </p>
        <p class="w-full">
          FOR DEVELOPERS, THIS MEANS EASIER INTEGRATION, REDUCED TECHNICAL OVERHEAD, AND THE ABILITY TO BUILD MORE INNOVATIVE SOLUTIONS WITHOUT BEING CONSTRAINED BY NETWORK-SPECIFIC LIMITATIONS.
          <br><br>
          ULTIMATELY, ASSET ABSTRACTION WILL CREATE A MORE FLUID FINANCIAL ECOSYSTEM, ALLOWING ASSETS TO BE TRANSFERRED, TRADED, AND UTILIZED EFFORTLESSLY ACROSS ANY PLATFORM, EMPOWERING BOTH USERS AND DEVELOPERS TO ACHIEVE THEIR GOALS WITH GREATER EFFICIENCY.
        </p>
      </div>
    </div>
    <div class="mt-[33px] md:mt-[60px] aspect-[1680/676]">
      <img
        class="w-full h-full"
        src="@/assets/images/empowering-pc.jpg"
      >
    </div>
  </div>
</template>

<style lang="scss" scoped>

</style>
